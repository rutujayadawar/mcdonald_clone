# mcdonald-clone-project
The "mcdonald-clone" repo replicates the McDonald's website &amp; app using modern web technologies. It's a learning platform for devs and provides an experience close to the original website. Contributions are welcome, and it's licensed under MIT.
